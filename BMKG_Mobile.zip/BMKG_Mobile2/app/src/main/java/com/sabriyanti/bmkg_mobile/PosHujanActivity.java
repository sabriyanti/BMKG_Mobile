package com.sabriyanti.bmkg_mobile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PosHujanActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pos_hujan);
    }
}