package com.sabriyanti.bmkg_mobile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
    }

    public void website(View view) {
        String url= "https://staklim-kalbar.bmkg.go.id/";
        Intent bukaWebsite = new Intent(Intent.ACTION_VIEW);
        bukaWebsite.setData(Uri.parse(url));
        startActivity(bukaWebsite);
    }


    public void Instagram(View view) {
        String url= "https://www.instagram.com/infoiklimkalbar?igsh=MXYzMmtoeW42dzkwdw==";
        Intent bukaWebsite = new Intent(Intent.ACTION_VIEW);
        bukaWebsite.setData(Uri.parse(url));
        startActivity(bukaWebsite);
    }


    public void map(View view) {
        String url= "https://maps.app.goo.gl/1eufXTDxYkp1krff6";
        Intent bukaMap = new Intent(Intent.ACTION_VIEW);
        bukaMap.setData(Uri.parse(url));
        startActivity(bukaMap);
    }
}